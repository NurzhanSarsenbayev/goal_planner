 # Roadmap

## Phase 0: Setup

Status: done.

- Install Flutter.
- Install Android Studio.
- Configure Android emulator.
- Create Flutter project.
- Run app on emulator.
- Commit initial project.

## Phase 1: App shell

Status: done.

- Replace counter app.
- Add Material 3 theme.
- Add bottom navigation.
- Add Today, Goals, Calendar, More placeholder screens.

## Phase 2: In-memory prototype

Status: done.

Goal:

Build the first working version of the core loop without database or backend.

Implemented:

- Create Goal model.
- Create Milestone model.
- Create PlannerTask model.
- Add sample in-memory state.
- Build Goals screen.
- Build Goal Details screen.
- Add goal creation.
- Add task creation inside goal.
- Schedule task for today.
- Show scheduled tasks on Today screen.
- Complete task.
- Show simple goal progress.
- Add milestone tasks.
- Add direct goal tasks.
- Add standalone tasks from Today.

Result:

A user can manually test:

> create goal -> add milestone/direct task -> schedule for today -> complete task -> see progress

## Phase 3: Local-first persistence

Status: done.

Goal:

Make app data survive restarts.

Implemented:

- Add Drift.
- Create local SQLite database.
- Add goals table.
- Add milestones table.
- Add tasks table.
- Add PlannerRepository.
- Add database mappers.
- Replace in-memory-only storage with local persistence.
- Keep app state synchronized with local database.
- Persist:
    - goals;
    - milestones;
    - tasks;
    - completion state;
    - scheduled date;
    - task placement.

Result:

App data survives restart.

## Phase 4: Core MVP task/goal management

Status: mostly done.

Goal:

Make the app usable for personal testing of the goal-linked planning loop.

Implemented:

### Goals

- Create goal.
- Edit goal.
- Delete goal with strong confirmation.
- Show goal progress.

### Milestones

- Create milestone.
- Edit milestone.
- Delete milestone with choice:
    - move tasks to Direct tasks;
    - delete milestone and tasks.

### Tasks

- Create task from Goal Details.
- Create task from Today.
- Create standalone task.
- Create direct goal task.
- Create milestone task.
- Edit task.
- Delete task.
- Complete / uncomplete task.
- Plan task for Today.
- Remove task from Today.
- Attach standalone task to goal / milestone.
- Detach goal-linked task back to standalone.
- Move direct goal task to milestone.
- Move milestone task to Direct tasks.

### Screens

- Today screen.
- Goals screen.
- Goal Details screen.
- All Tasks screen.
- More screen.
- Calendar placeholder before Phase 5.

### Refactoring completed

- Extract GoalDetailsController.
- Extract AllTasksController.
- Extract app dialog helpers.
- Extract planner seed service.
- Add safer domain model update methods.
- Separate repository mappers.

Current result:

The app supports the main task placement lifecycle:

> Standalone task ↔ Direct goal task ↔ Milestone task

And the main execution loop:

> Goal -> Milestone / Direct task -> Today -> Complete -> Progress

## Phase 5: Date planning and calendar MVP

Status: done.

Goal:

Move from “Today-only planning” to basic scheduled-date planning.

Implemented:

- Add date picker for task scheduling.
- Keep quick action: Plan today.
- Add Schedule date action for tasks.
- Show scheduled date in TaskCard.
- Support scheduling tasks from:
  - All Tasks;
  - Goal Details;
  - Today;
  - Calendar.
- Support rescheduling tasks to another date.
- Support removing scheduled date while keeping task visible in All Tasks.
- Add Calendar screen.
- Add visual month grid.
- Highlight selected day.
- Highlight today.
- Mark days that have scheduled tasks.
- Show tasks for selected day.
- Allow task actions from Calendar:
  - complete / uncomplete;
  - edit;
  - reschedule;
  - remove scheduled date;
  - delete.
- Add task creation from Calendar for selected date.
- Support task placement when creating from Calendar:
  - standalone task;
  - direct goal task;
  - milestone task.
- Persist scheduled date after restart.

Refactoring completed during this phase:

- Extract shared planner date helpers.
- Extract calendar month grid widget.
- Show only selected day tasks in Calendar.
- Rename task creation placement dialog.
- Organize widgets by feature:
  - common;
  - calendar;
  - goals;
  - milestones;
  - tasks.

Current result:

A user can schedule tasks not only for today, but for future dates.

A user can manually test:

> create goal -> add milestone/direct task -> schedule task for future date -> open Calendar -> select date -> see task -> complete task -> see goal progress

Calendar is now useful as a basic planning surface, not a full calendar product.

Not implemented yet:

- time-of-day scheduling;
- recurring tasks;
- drag-and-drop planning;
- week/day calendar views;
- year calendar view;
- meetings / birthdays as separate event types;
- reminders / notifications.

## Phase 6: Reports and validation analytics MVP

Status: mostly done.

Goal:

Show useful progress feedback without overbuilding analytics.

The main question this phase should answer:

> Did daily actions actually move long-term goals, or did the app become a generic todo list?

Implemented:

### Today execution feedback

- Add Done today section to Today screen.
- Show tasks completed today based on `completedAt`.
- Keep pending today tasks separate from completed today tasks.
- Add Overdue section to Today screen.
- Show overdue tasks separately from today's planned tasks.
- Support removing scheduled date from overdue tasks.
- Support moving overdue tasks back to Today.
- Support date-aware completion flow:
  - today / unscheduled task -> complete today;
  - past scheduled task -> choose completion date;
  - future scheduled task -> confirm early completion;
  - completed task -> uncomplete without dialog.
- Apply date-aware completion flow across:
  - Today;
  - Calendar;
  - All Tasks;
  - Goal Details.

### Reports screen

- Add Reports screen accessible from More.
- Support quick report periods:
  - Today;
  - Last 7 days;
  - Last 14 days.
- Show completed tasks for selected period.
- Show summary card:
  - completed task count;
  - planned task count;
  - plan completion percent;
  - current completion streak.
- Show goal contribution:
  - completed tasks per goal;
  - standalone completed tasks.
- Show completed tasks grouped by day.
- Show completed count in each day section.
- Refresh Reports screen when store data changes.
- Support complete / uncomplete from Reports.

### Report logic and tests

- Extract report calculation from UI.
- Add report builder.
- Add report period model.
- Add report summary model.
- Add unit tests for:
  - Today period;
  - Last 7 days period;
  - Last 14 days period;
  - goal-linked vs standalone counts;
  - active days;
  - day grouping;
  - planned task count;
  - plan completion percent;
  - current streak.

### Refactoring completed during this phase

- Extract report widgets:
  - report period selector;
  - report summary card;
  - goal report section;
  - day report section;
  - empty report card.
- Fix completed task title decoration.
- Keep Reports screen focused on screen orchestration.

Current result:

A user can see:

- what is planned for today;
- what is overdue;
- what was completed today;
- what was completed over the last 7 / 14 days;
- how many planned tasks were actually completed;
- which goals received completed actions;
- how many days in a row they completed at least one task.

A user can manually test:

> create goal -> add milestone/direct task -> schedule tasks -> complete tasks across days -> open Reports -> switch Today / 7 days / 14 days -> see completed work, plan completion, streak, goal contribution and by-day history

Validation value:

This phase helps evaluate whether the app is used as a goal-linked planner or just as a simple todo list.

The most important validation signals are:

- user completes tasks linked to goals;
- user checks Reports;
- user understands plan completion;
- user notices overdue tasks and reschedules or completes them;
- user can review the last 7 / 14 days and see meaningful goal progress.

Not implemented yet:

- custom selected-day report;
- custom date ranges;
- weekly comparison;
- monthly / yearly analytics;
- charts;
- productivity score;
- AI-generated reviews;
- export;
- habit analytics.

## Phase 6.5: Recurring task planning MVP

Status: done.

Goal:

Make repeated tasks easy to plan without manually scheduling each date.

Problem:

Some tasks repeat on predictable patterns, for example:

- workout on Monday / Wednesday / Friday;
- take out trash every Friday;
- pay something every 15th;
- weigh in once a month;
- weekly planning every Sunday.

Current architecture decision:

Recurring tasks are implemented as:

> RecurringTaskRule -> generated PlannerTask occurrences

A recurring rule defines the repeated task.

Generated occurrences are normal `PlannerTask` items with:

- concrete `scheduledDate`;
- optional `goalId`;
- optional `milestoneId`;
- `recurringRuleId` linking them back to the rule.

This lets Today, Calendar and Reports work with recurring occurrences mostly like normal scheduled tasks.

Implemented:

### Domain model

- Add `RecurringTaskRule`.
- Add recurrence types:
  - weekly;
  - monthly.
- Support weekly weekdays:
  - Monday;
  - Tuesday;
  - Wednesday;
  - Thursday;
  - Friday;
  - Saturday;
  - Sunday.
- Support monthly day selection.
- Support monthly day fallback:
  - if the selected day does not exist in a month, occurrence is created on the last day of that month;
  - example: day 31 -> February 28/29, April 30.
- Add `RecurringTaskException`.
- Add `recurringRuleId` to `PlannerTask`.

### Tests

- Add tests for weekly rule matching.
- Add tests for monthly rule matching.
- Add tests for inactive rules.
- Add tests for start/end date boundaries.
- Add tests for monthly last-day fallback.
- Add tests for recurring exceptions.
- Add tests for recurring occurrence generation.
- Add tests preventing duplicate generated occurrences.
- Add tests for recurring occurrence lifecycle:
  - delete occurrence;
  - reschedule occurrence;
  - unschedule occurrence.
- Add tests for recurring rule lifecycle:
  - activate rule;
  - deactivate rule;
  - delete rule;
  - update rule and rebuild future occurrences.

### Persistence

- Upgrade Drift schema to version 2.
- Add `recurring_task_rules` table.
- Add `recurring_task_exceptions` table.
- Add nullable `recurringRuleId` column to `tasks`.
- Add migration from schema v1 to v2.
- Add repository mapping for recurring rules.
- Add repository mapping for recurring exceptions.
- Persist generated recurring task occurrences as normal tasks.
- Persist recurring rule creation transactionally:
  - save rule;
  - save generated occurrences.
- Clean recurring data when deleting goals and milestones:
  - deleting a goal removes related recurring rules and exceptions;
  - deleting a milestone with tasks removes related recurring rules and exceptions;
  - deleting a milestone while moving tasks to direct goal detaches related recurring rules from the milestone.

### Recurring occurrence generation

- Add recurring task occurrence generator.
- Generate concrete `PlannerTask` occurrences from active rules.
- Respect recurring exceptions.
- Avoid duplicate occurrences.
- Use deterministic generated task IDs.
- Generate upcoming occurrences on app start.
- Refactor generator to support arbitrary date ranges:
  - `startDate`;
  - `endDate`.
- Keep upcoming generation for near-term Today usage.
- Generate recurring occurrences for visible Calendar month.
- Refresh visible Calendar month after creating a recurring rule from Calendar.

### Store and lifecycle integration

- Load recurring rules into `PlannerStore`.
- Load recurring exceptions into `PlannerStore`.
- Add recurring rule creation to `PlannerStore`.
- Generate and persist upcoming occurrences when a rule is created.
- Generate and persist missing occurrences when Calendar opens a visible month.
- Extract recurring occurrence lifecycle:
  - delete occurrence;
  - reschedule occurrence;
  - unschedule occurrence.
- Extract recurring rule lifecycle:
  - activate rule;
  - deactivate rule;
  - delete rule;
  - update rule and rebuild future occurrences.
- Keep `PlannerStore` as state coordinator while recurring lifecycle decisions move into dedicated recurring lifecycle classes.

### UI

- Add `Recurring tasks` screen.
- Add entry point from More.
- Add recurring rule list.
- Add reusable recurring rule card.
- Add recurring rule creation dialog from Recurring Tasks screen.
- Add recurring rule editing flow.
- Add recurring rule activate/deactivate actions.
- Add recurring rule delete action.
- Support recurring rule placement:
  - standalone recurring task;
  - direct goal recurring task;
  - milestone recurring task.
- Support weekly rule creation.
- Support monthly rule creation.
- Disable Add button until recurring rule form is valid.
- Allow monthly day 1-31.
- Show helper text explaining monthly last-day fallback.
- Split recurring rule dialog into smaller sections:
  - placement section;
  - schedule section.
- Show recurring rules in All Tasks instead of flooding All Tasks with future generated occurrences.
- Hide future uncompleted recurring occurrences from default All Tasks view.
- Keep today / overdue / completed recurring occurrences visible in All Tasks.
- Add recurring task creation from Today.
- Add recurring task creation from Calendar.
- For Calendar recurring creation:
  - use selected date as recurring rule start date;
  - preselect weekday based on selected date;
  - preselect monthly day based on selected date;
  - show past-date warning when creating from a past date.

### Occurrence behavior

- Deleting one generated recurring occurrence:
  - creates a `RecurringTaskException`;
  - deletes only the selected occurrence;
  - prevents that occurrence from being regenerated after Calendar month regeneration or app restart.
- Rescheduling one generated recurring occurrence:
  - creates a `RecurringTaskException` for the old date;
  - detaches the moved task from the recurring rule;
  - keeps the moved task as a one-off scheduled task.
- Unscheduling one generated recurring occurrence:
  - creates a `RecurringTaskException` for the old date;
  - detaches the task from the recurring rule;
  - keeps the task as a one-off unscheduled task.
- Completing one occurrence affects only that occurrence.
- Editing a recurring rule:
  - updates the rule;
  - removes future unfinished generated occurrences from the old rule shape;
  - generates future occurrences from the updated rule;
  - keeps completed history.
- Deactivating a recurring rule:
  - marks the rule inactive;
  - removes unfinished generated occurrences;
  - keeps completed history.
- Activating a recurring rule:
  - marks the rule active;
  - regenerates upcoming occurrences;
  - still respects existing exceptions.
- Deleting a recurring rule:
  - deletes the rule;
  - removes unfinished generated occurrences;
  - keeps completed occurrences as detached history;
  - removes exceptions for the deleted rule.

Current result:

A user can create, edit, deactivate, activate, and delete recurring task rules.

Examples:

> Workout every Monday, Wednesday and Friday

> Pay taxes monthly on day 31

The app generates concrete scheduled task occurrences.

Generated occurrences appear in:

- Today, if occurrence is scheduled for today;
- Calendar, when the relevant month is opened;
- Reports, as planned/completed tasks;
- All Tasks only when actionable/history-relevant.

All Tasks shows recurring rules separately, instead of being flooded with future generated occurrences.

Expected result for Phase 6.5 done:

A user can:

- create weekly recurring tasks;
- create monthly recurring tasks;
- link recurring tasks to goals/milestones;
- create recurring tasks from More;
- create recurring tasks from Today;
- create recurring tasks from Calendar;
- see generated occurrences in Today and Calendar;
- complete one occurrence without completing the whole series;
- delete one occurrence without it being regenerated;
- reschedule one occurrence without changing the whole series;
- unschedule one occurrence without it being regenerated;
- edit a recurring rule and rebuild future unfinished occurrences;
- deactivate and reactivate a recurring rule;
- delete a recurring rule while keeping completed history;
- avoid All Tasks being flooded with future generated occurrences.

Not doing in recurring MVP:

- complex RRULE support;
- yearly recurrence;
- every N days recurrence;
- time-of-day scheduling;
- reminders;
- drag-and-drop recurring occurrences;
- edit this and following;
- advanced recurrence exceptions;
- habit streaks;
- full habit system.

## Phase 6.6: Architecture stabilization before Habits

Status: not started.

Goal:

Prepare the codebase for larger feature growth before adding Habits.

The app now has enough real product behavior that continuing with the current MVP structure would make future changes harder, riskier and slower.

This phase is about making the codebase easier to extend, test and reason about.

Reason:

Phase 6.5 added serious recurring task behavior:

- recurring rules;
- generated task occurrences;
- occurrence exceptions;
- rule editing;
- rule activation/deactivation;
- rule deletion;
- recurring creation from Today;
- recurring creation from Calendar;
- Calendar month generation;
- All Tasks filtering;
- Reports compatibility.

The feature works, but it also exposed architectural pressure.

Main architectural risks:

- `PlannerStore` still coordinates too many domains:
  - goals;
  - milestones;
  - tasks;
  - recurring rules;
  - recurring occurrence generation;
  - persistence orchestration.
- `PlannerRepository` still owns persistence for multiple aggregates.
- `AppShell` still owns too many dialog flows and screen callbacks.
- Large screens still mix rendering, local state, action sheets, dialogs and user intent handling.
- Some controllers use optimistic local updates that may diverge from recurring-aware store behavior.
- Future features like Habits, reminders, filters, search and richer Calendar views would increase this complexity if added now.

Architecture direction:

Move toward a practical feature-based structure without a big-bang rewrite.

Target direction:

- `lib/app/`
  - `app_shell.dart`
  - `actions/`
- `lib/core/`
  - `dates/`
- `lib/data/`
  - `local/`
  - `repositories/`
- `lib/features/recurring/`
  - `application/`
  - `domain/`
  - `presentation/`
- `lib/features/tasks/`
  - `application/`
  - `presentation/`
- `lib/features/goals/`
  - `application/`
  - `presentation/`
- `lib/features/calendar/`
  - `presentation/`
- `lib/features/reports/`
  - `application/`
  - `presentation/`

This is a direction, not a requirement to move every file immediately.

The goal is to reduce coupling and clarify responsibilities step by step.

Initial architecture stabilization scope:

### Recurring architecture

- Extract recurring task application service.
- Move recurring orchestration out of `PlannerStore`.
- Keep `PlannerStore` as a thin state coordinator.
- Extract recurring repository from `PlannerRepository`.
- Keep recurring lifecycle logic covered by tests.
- Keep recurring behavior unchanged after refactor.

### Task architecture

- Extract task application service.
- Separate normal task operations from recurring-aware task operations.
- Review scheduling, unscheduling, completion, attachment, detachment and deletion flows.
- Ensure recurring occurrence behavior remains correct.

### Goal and milestone architecture

- Extract goal application service.
- Extract milestone application service.
- Keep goal/milestone deletion behavior consistent with recurring data cleanup.
- Make goal/milestone operations easier to extend later.

### AppShell cleanup

- Extract goal dialog actions from `AppShell`.
- Extract task dialog actions from `AppShell`.
- Keep `AppShell` focused on:
  - app lifecycle;
  - navigation;
  - high-level screen wiring.

### Screen cleanup

- Review `AllTasksScreen` and `AllTasksController`.
- Remove or simplify optimistic local state if it conflicts with store behavior.
- Split `GoalDetailsScreen` into smaller sections/actions.
- Split `CalendarScreen` responsibilities where needed.
- Keep screens focused on rendering state and emitting user intents.

### Repository cleanup

- Split persistence responsibilities where it reduces coupling.
- Avoid making one repository responsible for every aggregate.
- Keep cross-aggregate transactions explicit and named clearly.

Definition of done:

- `PlannerStore` is significantly thinner and mostly coordinates state.
- Recurring application logic is not embedded directly in `PlannerStore`.
- Recurring persistence is not buried inside one general repository.
- `AppShell` no longer owns most dialog workflows.
- Large screens are split where it improves readability and extension.
- Existing recurring behavior still works after refactor.
- `flutter analyze` passes.
- `flutter test` passes.
- Manual QA for recurring flows passes again.

Not doing in this phase:

- Full rewrite to strict Clean Architecture.
- Dependency injection framework.
- Moving every model into feature folders in one big change.
- Riverpod migration.
- Backend/sync.
- New product features.

## Phase 7: Habits MVP

Status: not started.

Goal:

Add recurring daily behavior tracking only after reports, recurring task planning and architecture stabilization are stable.

Why this is separate from recurring tasks:

Recurring tasks are planned actions that appear as concrete tasks on specific dates.

Habits are routines tracked over time, where history and consistency matter more than a single task instance.

Initial habit scope:

- Create habit.
- Edit habit.
- Delete habit.
- Habit title.
- Optional description.
- Daily checkbox.
- Optional weekdays.
- Optional time.
- Show timed habits in Today.
- Show untimed habits in a simple habit list.
- Mark habit complete for a day.
- Store habit completion history.
- Show simple habit completion history.

Expected result:

A user can track routines like:

- 10,000 steps;
- meditation;
- drink water;
- reading;
- stretching.

Not doing initially:

- complex streak gamification;
- habit analytics;
- habit templates;
- habit categories;
- penalties;
- social features;
- reminders;
- weight tracker;
- expense tracker.

## Phase 8: Product validation

Status: not started.

Goal:

Test whether the product idea is actually useful.

Validation plan:

- Give app to first real user for 7-14 days.
- Track what is used daily.
- Track what is ignored.
- Track what creates friction.
- Do not add large new features during validation.

Success signals:

- User opens Today daily.
- User creates goals.
- User links tasks to goals.
- User completes tasks.
- User checks progress/report.
- User reviews the last 7 / 14 days.
- User understands planned vs completed tasks.
- User uses overdue tasks instead of losing old planned tasks.
- User can see which goals received real completed actions.
- User understands the difference between standalone, direct goal and milestone tasks.
- User understands recurring tasks and uses them for repeated planned actions.

Failure signals:

- User only uses it as a simple todo list.
- Goals are ignored.
- Milestones are ignored.
- Reports are ignored.
- Recurring tasks are ignored or misunderstood.
- User returns to previous planner.

## Phase 9: Backend and sync

Status: later.

Only after local MVP is validated.

Potential backend stack:

- FastAPI
- PostgreSQL
- Redis
- Docker
- Alembic
- JWT

Backend responsibilities:

- accounts;
- backup;
- sync;
- AI endpoint later;
- subscription later.

## Product positioning

Current product direction:

A goal-linked daily planner, not a generic all-in-one life app.

Core loop:

> Goal -> Milestone / Direct task -> Today -> Complete -> Progress / Report

Main differentiator:

- connect long-term goals with daily execution;
- make task placement flexible;
- keep Today practical;
- support repeated planned actions without turning the app into a full habit/productivity suite too early;
- avoid turning the app into a bloated “whole life” tracker too early.

## Current limitations

- No time-of-day scheduling yet.
- Recurring task planning MVP exists, but advanced recurrence rules are not supported yet.
- No habits.
- No habit completion history.
- Architecture stabilization is required before adding Habits.
- Reports support only Today / Last 7 days / Last 14 days.
- No custom selected-day report yet.
- No custom report date ranges.
- No weekly comparison.
- No monthly / yearly analytics.
- No search/filtering in All Tasks.
- No drag-and-drop planning.
- No week/day/year calendar views.
- No separate meeting / birthday event model.
- No reminders / notifications.
- No cloud sync/backend.
- No auth.
- No serious design polish yet.
- Sample seed data still exists for development.
- State management is still custom ChangeNotifier-based; Riverpod is not introduced yet.

## Not doing now

- AI decomposition.
- Gamification.
- Weight tracker.
- Expense tracker.
- Complex calendar.
- Cloud backend.
- Subscriptions.
- iOS release.
- Heavy design polish.