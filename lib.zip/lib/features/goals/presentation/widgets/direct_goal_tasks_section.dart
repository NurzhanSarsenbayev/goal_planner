import 'package:flutter/material.dart';

import '../../../../models/goal.dart';
import '../../../../models/planner_task.dart';
import '../../../../widgets/tasks/task_card.dart';
import '../../../../widgets/common/section_header.dart';

class DirectGoalTasksSection extends StatelessWidget {
  const DirectGoalTasksSection({
    super.key,
    required this.goal,
    required this.tasks,
    required this.onAddTask,
    required this.onToggleTaskCompleted,
    required this.onEditTask,
    required this.onMoveTaskToMilestone,
    required this.onScheduleTaskForToday,
    required this.onScheduleTaskForDate,
    required this.onDeleteTask,
  });

  final Goal goal;
  final List<PlannerTask> tasks;
  final VoidCallback onAddTask;
  final void Function(PlannerTask task) onToggleTaskCompleted;
  final void Function(PlannerTask task) onEditTask;
  final void Function(PlannerTask task) onMoveTaskToMilestone;
  final void Function(String taskId) onScheduleTaskForToday;
  final void Function(PlannerTask task) onScheduleTaskForDate;
  final void Function(String taskId) onDeleteTask;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SectionHeader(
          title: 'Direct tasks',
          actionLabel: 'Add task',
          onActionPressed: onAddTask,
        ),
        const SizedBox(height: 8),
        if (tasks.isEmpty)
          Text('No direct tasks.', style: Theme.of(context).textTheme.bodySmall)
        else
          ...tasks.map(
            (task) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: TaskCard(
                task: task,
                goal: goal,
                onToggleCompleted: () => onToggleTaskCompleted(task),
                onEdit: () => onEditTask(task),
                onMoveToMilestone: () => onMoveTaskToMilestone(task),
                onScheduleForToday: () => onScheduleTaskForToday(task.id),
                onScheduleDate: () {
                  onScheduleTaskForDate(task);
                },
                onDelete: () => onDeleteTask(task.id),
              ),
            ),
          ),
      ],
    );
  }
}
